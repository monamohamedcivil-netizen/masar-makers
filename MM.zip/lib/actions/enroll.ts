"use server";

import { revalidatePath } from "next/cache";

import { createClient } from "@/lib/supabase/server";

export type EnrollmentStatus =
  | "pending"
  | "active"
  | "rejected"
  | "expired"
  | "suspended"
  | "completed"
  | "cancelled";

export interface EnrollmentRequestResult {
  success: boolean;
  message?: string;
  enrollment?: {
    id: string;
    status: EnrollmentStatus;
  };
  whatsapp?: {
    number: string;
    studentName: string;
    studentEmail: string;
    courseTitle: string;
    journeyType: string;
    requestNumber: string;
  };
}

type CourseLookupRow = {
  id: string;
  slug: string;
  title: string;
  title_ar: string | null;
  station_id: string | null;
};
function looksLikeUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
    value,
  );
}

async function findCourse(
  supabase: Awaited<ReturnType<typeof createClient>>,
  courseId: string,
): Promise<CourseLookupRow | null> {
  const columns = "id,slug,title,title_ar,station_id";

  const { data: courseBySlug, error: slugError } = await supabase
    .from("courses")
    .select(columns)
    .eq("slug", courseId)
    .maybeSingle();

  if (slugError) {
    console.error(
      "Failed to find course by slug:",
      slugError.message,
    );
  }

  if (courseBySlug) {
    return courseBySlug as CourseLookupRow;
  }

  const { data: courseById, error: idError } = await supabase
    .from("courses")
    .select(columns)
    .eq("id", courseId)
    .maybeSingle();

  if (idError) {
    console.error(
      "Failed to find course by id:",
      idError.message,
    );
  }

  return (courseById as CourseLookupRow | null) ?? null;
}

export async function getEnrollment(courseId: string) {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const course = await findCourse(supabase, courseId);

  if (!course) return null;

  const { data } = await supabase
    .from("enrollments")
    .select("*")
    .eq("user_id", user.id)
    .eq("course_id", course.id)
    .maybeSingle();

  return data;
}

export async function requestEnrollment(
  courseId: string,
  journeyType?: string,
): Promise<EnrollmentRequestResult> {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return {
      success: false,
      message: "LOGIN_REQUIRED",
    };
  }
console.log("courseId =", courseId);

const { data: test } = await supabase
  .from("courses")
  .select("*");

console.log(test);
  const course = await findCourse(supabase, courseId);

  if (!course) {
    return {
      success: false,
      message: "لم يتم العثور على الكورس في قاعدة البيانات.",
    };
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name,email,phone")
    .eq("id", user.id)
    .maybeSingle();

  const studentName =
    profile?.full_name?.trim() ||
    user.user_metadata?.full_name ||
    user.user_metadata?.name ||
    user.email?.split("@")[0] ||
    "طالب جديد";

  const studentEmail = profile?.email || user.email || "غير متوفر";

 const resolvedJourneyType =
  journeyType?.trim() || "integrated";

   const whatsappNumber =
      process.env.NEXT_PUBLIC_WHATSAPP_NUMBER?.trim() || "";
    
  const buildWhatsappData = (
    enrollment: { id: string; status: EnrollmentStatus },
  ) => ({
    number: whatsappNumber,
    studentName,
    studentEmail,
    courseTitle: course.title_ar?.trim() || course.title,
    journeyType: resolvedJourneyType,
    requestNumber: `MM-${enrollment.id.slice(0, 8).toUpperCase()}`,
  });

  /*
   * The current production enrollments table is intentionally queried using
   * only user_id and course_id. station_id and journey_type are obtained from
   * the course record, so the action works even when those columns do not exist
   * in enrollments.
   */
  const { data: existing, error: existingError } = await supabase
    .from("enrollments")
      .select("id,status,journey_type")
  .eq("user_id", user.id)
  .eq("course_id", course.id)
  .eq("journey_type", resolvedJourneyType)
  .maybeSingle();

  if (existingError) {
    return {
      success: false,
      message: existingError.message,
    };
  }

  if (existing) {
    const typedExisting = existing as {
      id: string;
      status: EnrollmentStatus;
    };

    return {
      success: true,
      enrollment: typedExisting,
      whatsapp: buildWhatsappData(typedExisting),
    };
  }

const { data, error } = await supabase
  .from("enrollments")
  .insert({
  user_id: user.id,
  course_id: course.id,
  journey_type: resolvedJourneyType,
  status: "pending",
})
  .select("id,status,journey_type")
  .single();

  if (error || !data) {
    return {
      success: false,
      message: error?.message || "تعذر إنشاء طلب الاشتراك.",
    };
  }

  const enrollment = data as {
    id: string;
    status: EnrollmentStatus;
  };

  revalidatePath(`/course/${course.slug}`);
  revalidatePath("/admin");
  revalidatePath("/admin/students/enrollment-requests");
  revalidatePath("/dashboard");

  return {
    success: true,
    enrollment,
    whatsapp: buildWhatsappData(enrollment),
  };
}

export async function updateEnrollmentStatus(
  enrollmentId: string,
  status: EnrollmentStatus,
) {
  const supabase = await createClient();

  const { error } = await supabase
    .from("enrollments")
    .update({
      status,
      updated_at: new Date().toISOString(),
    })
    .eq("id", enrollmentId);

  if (error) {
    return {
      success: false,
      message: error.message,
    };
  }

  revalidatePath("/admin");
  revalidatePath("/admin/students/enrollment-requests");
  revalidatePath("/dashboard");

  return {
    success: true,
  };
}

export async function cancelEnrollment(courseId: string) {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return;

  const course = await findCourse(supabase, courseId);

console.log("courseId =", courseId);
console.log("course =", course);

  if (!course) return;

  await supabase
    .from("enrollments")
    .delete()
    .eq("user_id", user.id)
    .eq("course_id", course.id);

  revalidatePath(`/course/${course.slug}`);
}
