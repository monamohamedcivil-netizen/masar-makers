import { createClient } from "@/lib/supabase/server";

export type StudentProfile = {
  id: string;
  fullName: string;
  email: string;
  avatarUrl: string | null;
  role: string;
};

export type StudentCourseCard = {
  enrollmentId: string;
  courseId: string;
  slug: string;
  title: string;
  subtitle: string | null;
  imageUrl: string | null;
  journeyTitle: string | null;
  journeyType: string;
  progressPercent: number;
  completedLessons: number;
  totalLessons: number;
  status: "not_started" | "in_progress" | "completed";
  lastLessonId: string | null;
  lastLessonTitle: string | null;
  lastActivityAt: string | null;
  enrollmentStatus: string;
  careerPathId: string | null;
};

export type StudentSurvey = {
  id: string;
  title: string;
  formUrl: string | null;
  completed: boolean;
  completedAt: string | null;
};

export type StudentCertificate = {
  id: string;
  certificateNumber: string;
  courseTitle: string;
  issuedAt: string;
  fileUrl: string | null;
};

export type StudentProject = {
  id: string;
  title: string;
  description: string | null;
  status: string;
  projectUrl: string | null;
  createdAt: string;
};

export type StudentDashboardData = {
  profile: StudentProfile;
  studentName: string;
  studentEmail: string;
  activeCourses: StudentCourseCard[];
  pendingCourses: StudentCourseCard[];
  completedCourses: StudentCourseCard[];
  careerCourses: StudentCourseCard[];
  oneDayCourses: StudentCourseCard[];
  freeCourses: StudentCourseCard[];
  surveys: StudentSurvey[];
  certificates: StudentCertificate[];
  projects: StudentProject[];
  summary: {
    active: number;
    completed: number;
    pending: number;
    averageProgress: number;
    careerPaths: number;
    oneDay: number;
    free: number;
    surveysCompleted: number;
    surveysPending: number;
    certificates: number;
    projectsApproved: number;
  };
};

type Row = Record<string, unknown>;
type QueryResult = { data: Row[] | null; error: { message: string } | null };

const normalize = (value: unknown) => String(value ?? "").trim().toLowerCase();
const text = (value: unknown, fallback = "") =>
  typeof value === "string" && value.trim() ? value.trim() : fallback;
const nullableText = (value: unknown) =>
  typeof value === "string" && value.trim() ? value.trim() : null;
const numberValue = (value: unknown, fallback = 0) => {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
};
const booleanValue = (value: unknown) =>
  value === true || value === 1 || normalize(value) === "true" || normalize(value) === "completed";

const activeStatuses = new Set(["active", "approved", "enrolled", "confirmed"]);
const pendingStatuses = new Set(["pending", "requested", "waiting", "under_review"]);

function asRows(result: QueryResult): Row[] {
  return result.error ? [] : result.data ?? [];
}

async function loadProgressRows(
  supabase: Awaited<ReturnType<typeof createClient>>,
  userId: string,
  courseIds: string[],
): Promise<Row[]> {
  if (!courseIds.length) return [];

  // The live database currently uses student_course_progress. The fallback keeps
  // compatibility with installations created from the newer consolidated schema.
  const primary = await supabase
    .from("student_course_progress")
    .select("*")
    .eq("user_id", userId)
    .in("course_id", courseIds);

  if (!primary.error) return (primary.data ?? []) as Row[];

  const fallback = await supabase
    .from("course_progress")
    .select("*")
    .eq("user_id", userId)
    .in("course_id", courseIds);

  return fallback.error ? [] : ((fallback.data ?? []) as Row[]);
}

export async function getStudentDashboardData(): Promise<StudentDashboardData> {
  const supabase = await createClient();
  const { data: authData, error: authError } = await supabase.auth.getUser();
  if (authError || !authData.user) throw new Error("UNAUTHENTICATED");

  const user = authData.user;

  // Keep the enrollment query limited to columns that exist in the live schema.
  // journey_id and journey_type are intentionally not read from enrollments.
  const [profileResult, enrollmentResult] = await Promise.all([
    supabase.from("profiles").select("*").eq("id", user.id).maybeSingle(),
    supabase
      .from("enrollments")
      .select("id,user_id,course_id,status,created_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }),
  ]);

  if (enrollmentResult.error) throw new Error(enrollmentResult.error.message);

  const profile = (profileResult.data ?? {}) as Row;
  const enrollments = (enrollmentResult.data ?? []) as Row[];
  const courseIds = [
    ...new Set(enrollments.map((row) => text(row.course_id)).filter(Boolean)),
  ];

  const coursesResult = courseIds.length
    ? await supabase.from("courses").select("*").in("id", courseIds)
    : ({ data: [], error: null } as QueryResult);

  if (coursesResult.error) throw new Error(coursesResult.error.message);

  const courses = (coursesResult.data ?? []) as Row[];
  const stationIds = [
    ...new Set(courses.map((row) => text(row.station_id)).filter(Boolean)),
  ];

  const [progressRows, lessonsResult, journeysResult, stationsResult] = await Promise.all([
    loadProgressRows(supabase, user.id, courseIds),
    courseIds.length
      ? supabase.from("lessons").select("*").in("course_id", courseIds)
      : Promise.resolve({ data: [], error: null }),
    courseIds.length
      ? supabase.from("journeys").select("*").in("course_id", courseIds)
      : Promise.resolve({ data: [], error: null }),
    stationIds.length
      ? supabase.from("course_stations").select("*").in("id", stationIds)
      : Promise.resolve({ data: [], error: null }),
  ]);

  const lessons = asRows(lessonsResult as QueryResult).filter(
    (row) => row.is_published === undefined || Boolean(row.is_published),
  );
  const journeys = asRows(journeysResult as QueryResult).filter(
    (row) => row.is_active === undefined || Boolean(row.is_active),
  );
  const stations = asRows(stationsResult as QueryResult);

  const careerPathIds = [
    ...new Set(stations.map((row) => text(row.career_path_id)).filter(Boolean)),
  ];
  const pathsResult = careerPathIds.length
    ? await supabase.from("career_paths").select("*").in("id", careerPathIds)
    : ({ data: [], error: null } as QueryResult);
  const paths = asRows(pathsResult as QueryResult);

  const courseMap = new Map(courses.map((row) => [text(row.id), row]));
  const progressMap = new Map(progressRows.map((row) => [text(row.course_id), row]));
  const stationMap = new Map(stations.map((row) => [text(row.id), row]));
  const pathMap = new Map(paths.map((row) => [text(row.id), row]));

  const firstJourneyByCourse = new Map<string, Row>();
  for (const journey of [...journeys].sort(
    (a, b) => numberValue(a.display_order, 999) - numberValue(b.display_order, 999),
  )) {
    const courseId = text(journey.course_id);
    if (courseId && !firstJourneyByCourse.has(courseId)) {
      firstJourneyByCourse.set(courseId, journey);
    }
  }

  const lessonMap = new Map(lessons.map((row) => [text(row.id), row]));
  const lessonCountMap = new Map<string, number>();
  for (const lesson of lessons) {
    const courseId = text(lesson.course_id);
    lessonCountMap.set(courseId, (lessonCountMap.get(courseId) ?? 0) + 1);
  }

  const cards = enrollments
    .map((enrollment): StudentCourseCard | null => {
      const courseId = text(enrollment.course_id);
      const course = courseMap.get(courseId);
      if (!course) return null;

      const progress = progressMap.get(courseId) ?? {};
      const journey = firstJourneyByCourse.get(courseId) ?? {};
      const station = stationMap.get(text(course.station_id)) ?? {};
      const path = pathMap.get(text(station.career_path_id)) ?? {};
      const enrollmentStatus = normalize(enrollment.status || "pending");

      const rawPercent =
        progress.progress_percent ?? progress.progress ?? progress.completion_percentage ?? 0;
      const progressPercent = Math.max(0, Math.min(100, numberValue(rawPercent)));
      const completedLessons = numberValue(
        progress.completed_lessons ?? progress.completed_count,
      );
      const totalLessons = numberValue(
        progress.total_lessons ?? progress.lessons_count,
        lessonCountMap.get(courseId) ?? 0,
      );
      const lastLessonId = nullableText(
        progress.last_lesson_id ?? progress.current_lesson_id,
      );
      const completed =
        enrollmentStatus === "completed" ||
        normalize(progress.status) === "completed" ||
        progressPercent >= 100;
      const started =
        progressPercent > 0 ||
        completedLessons > 0 ||
        Boolean(progress.started_at ?? progress.last_activity_at ?? progress.updated_at);
      const status: StudentCourseCard["status"] = completed
        ? "completed"
        : started
          ? "in_progress"
          : "not_started";

      const courseType = normalize(
        course.journey_type ?? course.course_type ?? course.learning_mode ?? "career_path",
      );
      const journeyTitle =
        nullableText(path.title) ??
        nullableText(station.title) ??
        nullableText(journey.title);

      return {
        enrollmentId: text(enrollment.id),
        courseId,
        slug: text(course.slug, courseId),
        title: text(course.title_ar, text(course.title, text(course.name, "رحلة تعليمية"))),
        subtitle: nullableText(course.subtitle ?? course.description),
        imageUrl: nullableText(course.image_url ?? course.image_path),
        journeyTitle,
        journeyType: courseType,
        progressPercent,
        completedLessons,
        totalLessons,
        status,
        lastLessonId,
        lastLessonTitle: lastLessonId
          ? nullableText(lessonMap.get(lastLessonId)?.title)
          : null,
        lastActivityAt: nullableText(
          progress.last_activity_at ?? progress.last_viewed_at ?? progress.updated_at,
        ),
        enrollmentStatus,
        careerPathId: nullableText(station.career_path_id ?? course.career_path_id),
      };
    })
    .filter((card): card is StudentCourseCard => Boolean(card));

  const activeCourses = cards.filter((card) => activeStatuses.has(card.enrollmentStatus));
  const pendingCourses = cards.filter((card) => pendingStatuses.has(card.enrollmentStatus));
  const completedCourses = cards.filter(
    (card) => card.enrollmentStatus === "completed" || card.status === "completed",
  );
  const acceptedCourses = [
    ...activeCourses,
    ...completedCourses.filter(
      (item) => !activeCourses.some((active) => active.enrollmentId === item.enrollmentId),
    ),
  ];

  const isOneDay = (type: string) =>
    ["one_day", "one-day", "workshop", "single_day", "oneday"].includes(type);
  const isFree = (type: string) =>
    ["free", "free_session", "preview", "free-session"].includes(type);
  const oneDayCourses = acceptedCourses.filter((course) => isOneDay(course.journeyType));
  const freeCourses = acceptedCourses.filter((course) => isFree(course.journeyType));
  const careerCourses = acceptedCourses.filter(
    (course) => !isOneDay(course.journeyType) && !isFree(course.journeyType),
  );

  // Optional dashboard areas must never break the whole student workspace when
  // their tables have not been created yet.
  const [surveyResult, certificateResult, projectResult] = await Promise.all([
    supabase
      .from("survey_assignments")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }),
    supabase
      .from("certificates")
      .select("*")
      .eq("user_id", user.id)
      .order("issued_at", { ascending: false }),
    supabase
      .from("student_achievements")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false }),
  ]);

  const surveyAssignments = asRows(surveyResult as QueryResult);
  const surveyIds = [
    ...new Set(surveyAssignments.map((row) => text(row.survey_id)).filter(Boolean)),
  ];
  const surveysLookupResult = surveyIds.length
    ? await supabase.from("surveys").select("*").in("id", surveyIds)
    : ({ data: [], error: null } as QueryResult);
  const surveyLookup = new Map(
    asRows(surveysLookupResult as QueryResult).map((row) => [text(row.id), row]),
  );

  const surveys: StudentSurvey[] = surveyAssignments.map((row) => {
    const survey = surveyLookup.get(text(row.survey_id)) ?? {};
    return {
      id: text(survey.id, text(row.id)),
      title: text(survey.title, text(row.title, "استبيان")),
      formUrl: nullableText(
        survey.google_form_url ?? survey.form_url ?? row.form_url,
      ),
      completed: booleanValue(
        row.completed_status ?? row.is_completed ?? row.status,
      ),
      completedAt: nullableText(row.completed_at),
    };
  });

  const certificates: StudentCertificate[] = asRows(certificateResult as QueryResult)
    .filter((row) => row.is_revoked === undefined || !Boolean(row.is_revoked))
    .map((row) => {
      const course = courseMap.get(text(row.course_id)) ?? {};
      return {
        id: text(row.id),
        certificateNumber: text(row.certificate_number, "—"),
        courseTitle: text(
          course.title_ar,
          text(course.title, text(course.name, "شهادة إتمام")),
        ),
        issuedAt: text(row.issued_at, text(row.created_at, new Date(0).toISOString())),
        fileUrl: nullableText(row.file_url ?? row.file_path),
      };
    });

  const projects: StudentProject[] = asRows(projectResult as QueryResult).map((row) => ({
    id: text(row.id),
    title: text(row.title, "مشروع تدريبي"),
    description: nullableText(row.description),
    status: text(row.status, "pending"),
    projectUrl: nullableText(row.project_url ?? row.file_url),
    createdAt: text(row.created_at, new Date(0).toISOString()),
  }));

  const progressBearing = activeCourses.filter((course) => course.progressPercent > 0);
  const averageProgress = progressBearing.length
    ? Math.round(
        progressBearing.reduce((sum, course) => sum + course.progressPercent, 0) /
          progressBearing.length,
      )
    : 0;
  const pathKeys = new Set(
    careerCourses.map((course) => course.careerPathId || course.journeyTitle || course.courseId),
  );
  const fullName = text(
    profile.full_name ?? profile.name,
    text(user.user_metadata?.full_name, "مهندس مسار"),
  );
  const email = text(profile.email, user.email ?? "");

  return {
    profile: {
      id: user.id,
      fullName,
      email,
      avatarUrl: nullableText(profile.avatar_url),
      role: text(profile.role, "student"),
    },
    studentName: fullName,
    studentEmail: email,
    activeCourses,
    pendingCourses,
    completedCourses,
    careerCourses,
    oneDayCourses,
    freeCourses,
    surveys,
    certificates,
    projects,
    summary: {
      active: activeCourses.length,
      completed: completedCourses.length,
      pending: pendingCourses.length,
      averageProgress,
      careerPaths: pathKeys.size,
      oneDay: oneDayCourses.length,
      free: freeCourses.length,
      surveysCompleted: surveys.filter((item) => item.completed).length,
      surveysPending: surveys.filter((item) => !item.completed).length,
      certificates: certificates.length,
      projectsApproved: projects.filter((item) => normalize(item.status) === "approved").length,
    },
  };
}
